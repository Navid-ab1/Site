import mysql.connector as sql
class PurchaseReceipt:
    con = sql.connect(host='localhost', user='root', password='1234', database='company')
    cur = con.cursor()
    cur.execute(''' create table if not exists factor(factor_id int not null auto_increment primary key,
            item_number int not null ,
            name_customer varchar(25) not null,
            user_id int not null,
            branch_id int not null,
            price float(20,5),
            calculated_price float generated always as (price*1.25) stored,
            count_item int not null default 0,
            total_price_each float generated always as (calculated_price*count_item) stored,
            date_buy timestamp default current_timestamp ,
            trcking_number int not null
            );''')
