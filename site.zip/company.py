from person.person import Person
import mysql.connector as sql

con = sql.connect(host='localhost', user='root', password='1234', database='company')
# cur = con.cursor()
# cur.execute(''' CREATE TABLE if not exists company(
#     branch_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
#     name_br VARCHAR(30),
#     address_branch VARCHAR(40) NOT NULL DEFAULT '-----',
#     ceo_password VARCHAR(50) NOT NULL DEFAULT 'PaaWorD@',
#     name_ceo VARCHAR(30) NOT NULL,
#     sex_ceo VARCHAR(6),
#     provience_ceo VARCHAR(20),
#     );''')


class Company(Person):
    x = False
    y = False

    def __init__(self):
        super().__init__()
        self._id = 993
        self._name = "Navid's company"
        self._name_ceo = 'Navid'
        self._address = 'No12,blvd,NY'
        self._password = '236393'

    def username_checker(self, user):

        if self._name_ceo == user:
            Company.y = True
        else:
            Company.y = False
        return Company.y

    def password_checker(self, passwd):
        if self._password == passwd:
            Company.x = True
        else:
            Company.x = False
        return Company.x
