import sys

from admin.admin import *

ad = Admin()


def admin_method(per, itm):
    checker = True
    temp = False
    print('-' * 40)
    while True:
        print("")
        # user_id = input("Enter your userid: ")
        # passw = input("Enter you password: ")
        # checker = ad.entrant_checker(user_id, passw)
        if checker == True:
            y = admin_functions(per, itm)
            return (y)

        else:
            a = input("If you want to exit just print one or if you want to trying again just press Enter")
            if a == "1":
                sys.exit()
            else:
                pass




def admin_functions(per, itm):
    print(f"{x_o} \n {x_t} \n {x_th} \n {x_f} \n {x_s} \n {x_se} \n {x_ei} \n {x_te}+\
                \n {x_elev} \n {x_twel}")
    ad_in = input()
    if ad_in == '1':
        per.add_admin()
    elif ad_in == '2':
        number = input(x_fi)
        per.remove_admins(number)
    elif ad_in == '3':
        per.see_admins()
    elif ad_in == '4':
        itm.add_item()
    elif ad_in == '5':
        itm.show_item()
    elif ad_in == '6':
        id_re = int(input("Enter id's of item you want to remove: "))
        itm.remove_item(id_re)
    elif ad_in == '7':
        itm.show_categories()
    elif ad_in == '8':
        id = int(input("Enter the id you want to modify: "))
        num = int(input("what is the number you want to put in there: "))
        itm.update_entity = (id, num)


    elif ad_in == '9':
        return (False)

    elif ad_in == '10':  # add user
        pass

x = 'if you are Admin press 1: '
y = 'if you want to terminate app press 4: '
x_o = "Hello admin , tell me what do you want to do? "
x_t = "1:Add new admin: "
x_th = "2:remove admin: "
x_f = "3:show admins: "
x_fi = 'enter ssn of student you want to delete: '
x_s = "4:Add new item: "
x_te = "7:show categories:"
x_se = "5:show items: "
x_ei = "6:remove item: "
x_ni = 'Enter how do you want to do? '
x_elev = "8:Update quantity "
x_twel = "9:for going to previous "