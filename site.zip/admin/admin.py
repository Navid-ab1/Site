import mysql.connector as sql

from person import person

con = sql.connect(host='localhost', user='root', password='1234', database='company')
cur = con.cursor()


# cur.execute(''' create table if not exists admin(admin_id int not null auto_increment primary key,
#     salary float(20,5),
#     foreign key (admin_id) references person(id)
#     );''')


# import mysql.connector as sql# from mysql.connector import Error## try:#     con = sql.connect(host=\'localhost2\', user=\'root\', password=\'1234\')#     if con.is_connected():#         print(\'Successfully connected to MySQL database\')#         cur = con.cursor()#         cur.execute('create database company;")
# except Error as e:
#     print("Error while connecting to MySQL", e)
# finally:
#     if (con.is_connected()):
#         cur.close()
#         con.close()
# cur.execute("drop database company")
class Admin(person.Person):
    x = False
    y = False

    def __init__(self):
        super().__init__()
        self.adminnumber = 0
        self._admin_lst = []
        self._head_admins = ()

    def see_admins(self):  # solved
        cur.execute('''select * from (admin join person on admin_id =id  );''')
        print(cur.fetchall())

    def head_admins(self):
        self.name = 'Ali'
        self.family = 'Karimi'
        self.phone = '09361035313'
        self.provience = 'Tehran'
        self.id = '38383838'
        self.password = '22443'
        self.sex_prop = 'Male'
        self.degree_prop = 'Masters'

        self.admin_lst.append([self.id, self.password, self.name, self.family, self.phone, self.provience, self.sex_prop, self.degree_prop])

    def remove_admins(self, number):  # solved
        query = 'delete from admin where admin_id = %s ;'
        cur.execute(query, (number,))
        cur.execute('''select * from admin ;''')
        print(cur.fetchall())

    def add_admin(self):
        self.name = input("Enter name: ")
        self.family = input("Enter familyname : ")
        self.phone = input("Enter phone number(phone should be started with zero and eleven length): ")
        self.provience = input("Enter provience(Tehran,Alborz): ")
        self.id = input("Enter id card: ")
        self.sex_prop = input('Enter your sex(Male,Female): ')
        self.degree_prop = input('Enter your last degree(Associates,Bachorlers,Masters,Doctorate): ')
        self.password = self.password_maker()
        self.country = input("Enter country")
        self.martial_status = input("Enter martial status(Education pardon,immunity,submitted")
        self.salary = float(input("Enter numeric salary"))
        cur.execute('''insert into person(name,familyname,sex,provience,country,degree,password,martial_status)
                values (self.name,self.family,self.sex_prop,self.provience,self.country,self.degree_prop
               ,self.password,self.martial_status);''')
        # cur.execute('''insert into admin(salary) values (self.salary);''')

    # def entrant_checker(self, user_id, passw):
    #     Admin.y
    #     for i in range(len(self.admin_lst)):
    #         if self.admin_lst[i][0] == user_id and self.admin_lst[i][1] == passw:
    #             Admin.y = True
    #         else:
    #             Admin.y = False
    #         return Admin.y

    # def add_user():

    # def remove_user
    # def show_user


    @property
    def adminnumber(self):
        return self._adminnumber
    @adminnumber.setter
    def adminnumber(self, value):
        self._adminnumber = value

    @property
    def admin_lst(self):
        return self._admin_lst

    @admin_lst.setter
    def admin_lst(self, value):
        self._admin_lst.append(value)
'''Admin lst'''
    # @property
    # def adminnumber(self):
    #     return self._adminnumber
    #
    # @adminnumber.setter
    # def adminnumber(self, value):
    #     self._adminnumber = value
