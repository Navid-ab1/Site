from sys import *

from admin.admin_menu import *
from ceo_menu import *
from employee.employee import *
from employee.employee_menu import *
from item.item import *
from user import user_menu

per = Admin()
emp = Employee()
itm = Item()
# user = user_menu()

while True:
    print('-' * 40)
    print(
    f' Enter how do you want to do? \nif you are Admin press 1: \nif you are Employee press 2: \nif you want to terminate app press 4: ')
    print('if you are CEO press 3: ')
    print('If you are User press 4: ')

    inp = input()
    if inp == '1':
        admin_method(per, itm)
    elif inp == '2':
        employee_method(emp, itm)
    elif inp == '3':
        ceo_method(per, itm)
    elif inp == '4':
        user_menu.user_functions(itm)
    elif inp == '5':
        exit()
