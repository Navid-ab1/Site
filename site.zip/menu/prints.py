# -----------------Admin---------------------------
x = 'if you are Admin press 1: '
y = 'if you want to terminate app press 4: '
x_o = "Hello admin , tell me what do you want to do? "
x_t = "1:Add new admin: "
x_th = "2:remove admin: "
x_f = "3:show admins: "
x_fi = 'enter ssn of student you want to delete: '
x_s = "4:Add new item: "
x_te = "7:show categories:"
x_se = "5:show items: "
x_ei = "6:remove item: "
x_ni = 'Enter how do you want to do? '
x_elev = "8:Update quantity "
x_twel = "9:for going to previous "

# ------------------user------------------------------
u = "Hello user , tell me what do you want to do? "
u_o = '1:show items: '
u_t = '2:buy items: '
# ------------------employee--------------------------
e = "Hello employee , tell me what do you want to do? "
e_o = "1:Add new User: "
e_t = "2:remove User: "
e_th = "3:show Users: "
e_f = "4:Add new item: "
e_fi = "5:show items: "
e_s = "6:remove item: "
e_se = "7:show categories: "
e_ei = "8:Update quantity: "

# ------------------CEO--------------------------
c = "Hello Dear CEO , welcome to your Computer Company? \
    tell my what do you want to do: "
c_o = "1:Add new admin: "
c_t = "2:remove admin: "
c_th = "3:show admins: "
c_f = "4:Add new item: "
c_fi = "5:show items: "
c_s = "6:remove item: "
c_se = "7:show categories:"
c_ei = "8:Update quantity "
